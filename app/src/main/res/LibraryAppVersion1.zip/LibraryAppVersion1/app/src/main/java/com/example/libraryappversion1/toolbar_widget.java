package com.example.libraryappversion1;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class toolbar_widget extends AppWidgetProvider {


    public void onClick(View view){

        Log.i("Click Status: ", "Button Clicked");

        AppCompatActivity appCompatActivity = new AppCompatActivity();

        RemoteViews remoteViews = new RemoteViews(appCompatActivity.getPackageName(),
                R.layout.toolbar_widget_layout);
        remoteViews.setTextColor(R.id.searchBarTextView, appCompatActivity.getResources().getColor(R.color.colorPrimary));


    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        final int count = appWidgetIds.length;

        for (int i = 0; i < count; i++) {
            int widgetId = appWidgetIds[i];
            String number = String.format("%03d", (new Random().nextInt(900) + 100));

            RemoteViews remoteViews = new RemoteViews(context.getPackageName(),
                    R.layout.toolbar_widget_layout);
            remoteViews.setTextViewText(R.id.textView, number);

            Intent intent = new Intent(context, toolbar_widget.class);
            intent.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, appWidgetIds);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(context,
                    0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
            remoteViews.setOnClickPendingIntent(R.id.actionButton, pendingIntent);
            appWidgetManager.updateAppWidget(widgetId, remoteViews);
        }
    }
}

